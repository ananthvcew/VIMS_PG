# PHP QR Code

Multiple QR codes in pdf using PHPQRcode and FPDF libraries in PHP.
