<?php 
session_start(); 
include('top.php');
?>
<script  type="text/javascript" >
  function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
 function one()
 {  // window.alert("previous");
	 var x=document.f1.qq.value;
	// window.alert(x);
	  x=parseInt(x)-2;
	  if(x<0)
		  window.alert("First Question");
	  else
	  {
	  document.f1.qq.value=x;
	  document.f1.nxt.value=0;
	  document.f1.action="test.php";
	  document.f1.submit();
      }
  
 }
 function thre()
 {    
    
	  f1.action="test4.php";
	  f1.submit();
  }
    function secondPassed() {
                  $.ajax({
	url:"data1.php",
	method:"GET", 
	success:function(data){
	    console.log(data);
	    //seconds=data;
	    if(data=='0:0')
	     { f1.action="test4.php";
	         document.f1.submit();
	     }
	    document.getElementById('countdown').innerHTML = data;
	}
});

      }
      
      var countdownTimer = setInterval('secondPassed()',1000);
  </script>
 <style type=text/css>
.timer {
    width: 300px;
    font-size: 2.5em;
    text-align: center;
}
 </style>   
<?php
require('conn.php');
$s=new DBCON();
?>
   <div class="card">  Reg.Number :<?php 
	$regno= $_SESSION['regno'];    print $regno;
$scode=$_SESSION['branch'];
$tcode=$_SESSION['lang'];
//$du=6000;
//print  "&nbsp;&nbsp;&nbsp;&nbsp;Subject :" .$scode."-".$s->getsubname($scode);
 
	print "</div><div class='card'> Time Remaining : <time id='countdown'></time></div>";
?> 
<table>
  <form name='f1' method='post' action='test.php' enctype='multipart/form-data'   >
<?php
$scode=$_SESSION['branch'];
$tcode=$_SESSION['lang'];
$qno=$_SESSION["qno"];
$ans=$_SESSION["ans"];

if($_SESSION['hi']==1)
{
	$qq=$_SESSION['qq'];
	$nxt1=$_SESSION['nxt'];
	$set=$_SESSION['set'];
	$sqln="INSERT INTO tmark VALUES ($regno,'ques' , '$scode','$tcode', '$set',";
	$i=1;
	foreach($qno as $q2) 
   { $sqln=$sqln."'".$q2."', ";
     
     $i=$i+1;
   }
   for($j=$i;$j<=50;$j++)
   {
	   $sqln=$sqln." '',";
   }
	$sqln=$sqln."'0','60','completed' )";
	//print $sqln."<br>";
	$l=$s->linkarivu();
	$result = mysqli_query($l,$sqln);  
	if (!$result) {
     echo "Checking... Please Retry......";
     echo 'MySQL Error: ' . mysqli_error();
    } 
	
	$sqln="INSERT INTO tmark VALUES ($regno,'ans' , '$scode','$tcode', '$set', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',0,60,'pending') ";
	$l=$s->linkarivu();
	$result = mysqli_query($l,$sqln);  
	if (!$result) {
     echo "Checking... Please Retry......";
     echo 'MySQL Error: ' . mysqli_error();
    } 
	//print $sqln;
	}
else
{
	$qq=$_POST['qq'];
	$nxt1=$_POST['nxt']; //print "Current Next Value:".$nxt1."<br>";
	$set=$_POST['set'];
}
$an='';
$_SESSION['hi']=0;
//print "Current Index:".$qq."<br>";
if(($qq % 3)==0)
{ $i=1;
$sqln="update  tmark set";
foreach($ans as $a2) 
{ 
	$sqln=$sqln." q".$i."='".$a2."',";
  
  $i=$i+1;
}
 $rtime=$_SESSION['dur'];
 $sqln=$sqln." rtime=".$rtime ; 
 $sqln=$sqln."  where  regno='".$regno."' and type='ans'";
 //print $sqln;
 $l=$s->linkarivu();
	$result = mysqli_query($l,$sqln);  
	if (!$result) {
     echo "Checking... Please Retry......";
     echo 'MySQL Error: ' . mysqli_error();
    } 
}


$qn=$qno[$qq];
//print "Current question Number :".$qn."<br>";
$max=$s->getmaxques($scode,$tcode);
$tq=$s->gettotques($scode,$tcode,$set);
if($tq<$max)
	$max=$tq;
if($nxt1==1)
 {
if($qq>0)
{ $qqp=$qq-1;
 $nam="ans".$qqp; 
  //print " Previous index:".$qqp;
  $an=$_POST[$nam];
   $ans=$_SESSION['ans'];
  $ans[$qqp]=$an;
  $_SESSION['ans']=$ans;
 // print "Previous Answer".$an;
 
}
}
else
{
    if($qq>0)
    {
     $qqp=$qq+1;
     $nam="ans".$qqp; 
 // print " Previous index(Next):".$qqp;
    $an=$_POST[$nam];
    $ans=$_SESSION['ans'];
   $ans[$qqp]=$an;
   $_SESSION['ans']=$ans;
   // print "Previous Answer".$an;
    }
}
 $ans=$_SESSION['ans'];
 foreach($ans as $a11)
 // print "<br>Ans:".$a11;
 if($qq>0)
    {$an=$ans[$qq];
 // print "C.QNO:".$qq;
 //print " : Next :". $an;
	}
  
 

  	 $sql    = "select * from  ques where subcode='".trim($scode)."' and tcode='".trim($tcode)."' and qset='".trim($set)."' and qno =".$qn ;
	//print $sql;
	$l=$s->linkarivu();
 $result = mysqli_query($l,$sql);  
if (!$result) {
     echo "Checking... Please Retry......";
     echo 'MySQL Error: ' . mysqli_error();
    }
if ($row= mysqli_fetch_assoc($result)) 
 { 
   {$filename1='pict/'.$scode.'e'.$tcode.'qq'.$qn.'q.jpg';
   $filename2='pict/'.$scode.'e'.$tcode.'qq'.$qn.'a1.jpg';
 $filename3='pict/'.$scode.'e'.$tcode.'qq'.$qn.'a2.jpg';
 $filename4='pict/'.$scode.'e'.$tcode.'qq'.$qn.'a3.jpg';
 $filename5='pict/'.$scode.'e'.$tcode.'qq'.$qn.'a4.jpg';
   }
     $nam="ans".$qq;

  if (file_exists($filename1)) 
 {  // echo "The file $filename1 exists".$filename1;
 if(strlen($row['question']) > 200)
print "<tr ><td id='tabletext3'><textarea rows=10 cols=300 readonly> ". ($qq + 1) .". " .htmlentities($row['question']);
 else
 print "<tr ><td id='tabletext3'><textarea rows=4 cols=300 readonly> ". ($qq + 1) .". " .htmlentities($row['question'])."</textarea><br>";
 print "<img src='".$filename1."' /></td></tr>" ;
 }
 else 
  {//print strlen($row['question']);
      if(strlen($row['question']) > 200)
 print "<tr ><td id='tabletext3'> <textarea rows=10 cols=300 readonly> ". ($qq + 1) .". " .htmlentities($row['question'])."</textarea></td></tr>" ;
 else
  print "<tr ><td id='tabletext3'> <textarea rows=4 cols=300 readonly> ". ($qq + 1) .". " .htmlentities($row['question'])."</textarea></td></tr>" ;
 }if (file_exists($filename2)) 
 {  if($an=='A')
     print" <tr><td id='tabletext3'><input type=radio  checked = true name='".$nam."' value='A'>A. ". htmlentities(  $row['opt1']) ;
    else
     print" <tr><td id='tabletext3'><input type=radio   name='".$nam."' value='A'>A. ". htmlentities(  $row['opt1']) ;
 print "<img src='".$filename2."' /></td></tr>" ;
 }
 else
 {if($an=='A')
 print "<tr><td id='tabletext3'><input type=radio name='".$nam."'   checked = true value='A'>A. ". htmlentities(  $row['opt1'])."</td></tr>" ;
  else
  print "<tr><td id='tabletext3'><input type=radio name='".$nam."' value='A'>A. ". htmlentities(  $row['opt1'])."</td></tr>" ;
 }
  
  
   if (file_exists($filename3)) 
    { if($an=='B')
     print" <tr><td id='tabletext3'><input type=radio  checked = true name='".$nam."' value='B'>B. ". htmlentities(  $row['opt2']) ;
     else
        print" <tr><td id='tabletext3'><input type=radio name='".$nam."' value='B'>B. ". htmlentities(  $row['opt2']) ;
 print "<img src='".$filename3."'  /></td></tr>" ;
 }
 else
   {if($an=='B')
     print" <tr><td id='tabletext3'><input type=radio  checked = true name='".$nam."' value='B'>B. ". htmlentities(  $row['opt2']) ;
     else
       print "<tr><td id='tabletext3'> <input type=radio name='".$nam."' value='B'>B.". htmlentities( $row['opt2'])."</td></tr>" ;
   }
    if (file_exists($filename4)) 
 { if($an=='C')
     print" <tr><td id='tabletext3'><input type=radio  checked = true name='".$nam."' value='C'>C. ". htmlentities(  $row['opt3']) ;
     else
          print" <tr><td id='tabletext3'><input type=radio name='".$nam."' value='C'>C. ". htmlentities(  $row['opt3']) ;
 print "<img src='".$filename4."'  /></td></tr>" ;
 }
 else
 {
 if($an=='C')
     print" <tr><td id='tabletext3'><input type=radio  checked = true name='".$nam."' value='C'>C. ". htmlentities(  $row['opt3']) ;
 else
 print "<tr><td id='tabletext3'><input type=radio name='".$nam."' value='C'>C.".  htmlentities($row['opt3'])."</td></tr>" ;
 }
 if (file_exists($filename5)) 
  {if($an=='D')
     print" <tr><td id='tabletext3'><input type=radio  checked = true name='".$nam."' value='D'>D. ". htmlentities(  $row['opt4']) ;
     else
      print" <tr><td id='tabletext3'><input type=radio name='".$nam."' value='D'>D. ". htmlentities(  $row['opt4']) ;
 print "<img src='".$filename5."' /></td></tr>" ;
 }
 else
 { if($an=='D')
     print" <tr><td id='tabletext3'><input type=radio  checked = true name='".$nam."' value='D'>D. ". htmlentities(  $row['opt4']) ;
   else
 print "<tr><td id='tabletext3'> <input type=radio name='".$nam."' value='D'>D.". htmlentities( $row['opt4'])."</td></tr>" ;
}
	 $qq=$qq+1;
	 $_SESSION['qq']=$qq;
	  
	 print "<input type=hidden name=qq value='".$qq."'>"; 
	 print "<input type=hidden name=nxt value=1>"; 
	 
// }
 print " <input type=hidden name=scode value= ".$scode.">";	
print " <input type=hidden name=tcode value= ".$tcode.">";		
//$strans = implode(';', $ans);
//print " <input type=hidden name=ans1 value= ".$strans.">";	
//$strqno = implode(';', $qno);
//print " <input type=hidden name=qno1 value= ".$strqno.">";
print " <input type=hidden name=set value= ".$set.">";
print " <input type=hidden name=lstans>";
 if($qq==$max)
 {
	 print "<table><tr><td width=30%>   <input type='button'  onclick=thre() value='Submit' /></td> <td width=50%>  <input type='button' value='Previous' onclick=one() /> </td></tr></table>";
 }
	 else
	 {
 
 print "<table><tr><td width=50%>   <input type='submit'  value='Next' /></td><td width=50%>  <input type='button' value='Previous' onclick=one() /> </td></tr></table>";
	 } 

	
}

?>
 </table>
 </form>
       <td width="10px">&nbsp;</td>
   </tr>
   <tr>
     <td  colspan="4" height="90px">&nbsp;</td>
   </tr>
</table>

</body>
<?php
include('foot.html');
?>
</html>